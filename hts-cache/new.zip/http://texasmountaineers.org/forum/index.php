<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="http://texasmountaineers.org/forum/Themes/Reseller/css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="http://texasmountaineers.org/forum/Themes/Reseller/css/reseller.css" />
	<link rel="stylesheet" type="text/css" href="http://texasmountaineers.org/forum/Themes/Reseller/css/index.css?fin20" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>	
	<script type="text/javascript" src="http://texasmountaineers.org/forum/Themes/Reseller/scripts/bootstrap.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
		$("input[type=button]").attr("class", "btn btn-default btn-sm");
		$(".button_submit").attr("class", "btn btn-primary btn-sm");
		$("#advanced_search input[type='text'], #search_term_input input[type='text']").removeAttr("size"); 
		$(".table_grid").attr("class", "table table-striped");
		$("img[alt='New'], img.new_posts").replaceWith("<span class='label label-warning'>New</span>");
		$("#profile_success").removeAttr("id").removeClass("windowbg").addClass("alert alert-success"); 
		$("#profile_error").removeAttr("id").removeClass("windowbg").addClass("alert alert-danger"); 
	});
	</script>
	<script type="text/javascript" src="http://texasmountaineers.org/forum/Themes/default/scripts/script.js?fin20"></script>
	<script type="text/javascript" src="http://texasmountaineers.org/forum/Themes/Reseller/scripts/theme.js?fin20"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "http://texasmountaineers.org/forum/Themes/Reseller";
		var smf_default_theme_url = "http://texasmountaineers.org/forum/Themes/default";
		var smf_images_url = "http://texasmountaineers.org/forum/Themes/Reseller/images";
		var smf_scripturl = "http://texasmountaineers.org/forum/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "ISO-8859-1";
		var ajax_notification_text = "Loading...";
		var ajax_notification_cancel_text = "Cancel";
	// ]]></script>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<meta name="description" content="Login" />
	<meta name="keywords" content="texas mountaineers rock climbing texas" />
	<title>Login</title><link rel="shortcut icon" type="image/x-icon" href="http://texasmountaineers.org/wordpress/wp-content/uploads/favicon.ico" /><link rel="icon" href="http://texasmountaineers.org/wordpress/wp-content/uploads/favicon.ico" type="image/x-icon" />
	<link rel="help" href="http://texasmountaineers.org/forum/help/" />
	<link rel="search" href="http://texasmountaineers.org/forum/search/" />
	<link rel="contents" href="http://texasmountaineers.org/forum/index.php" />
	<script type="text/javascript">
		function smfAutoTask()
		{
			var tempImage = new Image();
			tempImage.src = "http://texasmountaineers.org/forum/index.php?scheduled=mailq;ts=1578332555";
		}
		window.setTimeout("smfAutoTask();", 1);
	</script>
	<script type="text/javascript">
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		ga('create', 'UA-66331810-1', 'texasmountaineers.org');
		ga('send', 'pageview');
	</script>
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
	function EzToogle(myEzItem,ezBlockID,myImage,isBlock)
	{
		var ezCollapseState = 0;

		if (document.getElementById && document.getElementById(myEzItem)!= null) {
			if (document.getElementById(myEzItem).style.display == "none")
			{
				document.getElementById(myEzItem).style.display = "";
				ezCollapseState = 0;
			}
			else
			{
				document.getElementById(myEzItem).style.display = "none";
				ezCollapseState = 1;
			}
		} else if (document.layers && document.layers[myEzItem]!= null) {
			if (document.layers[myEzItem].display == "none")
			{
				document.layers[myEzItem].display = "";
				ezCollapseState = 0;
			}
			else
			{
				document.layers[myEzItem].display = "none";
				ezCollapseState = 1;
			}
		} else if (document.all) {
			if (document.all[myEzItem].style.display == "none")
			{
				document.all[myEzItem].style.display = "";
				ezCollapseState = 0;
			}
			else
			{
				document.all[myEzItem].style.display = "none";
				ezCollapseState = 1;
			}
		}EzPortalSaveBlockState(ezBlockID,ezCollapseState,isBlock);
			if (myImage.src == "http://texasmountaineers.org/forum/Themes/Reseller/images/collapse.gif")
				myImage.src = "http://texasmountaineers.org/forum/Themes/Reseller/images/expand.gif";
			else
				myImage.src = "http://texasmountaineers.org/forum/Themes/Reseller/images/collapse.gif";

		}
	function EzPortalSaveBlockState(ezBlock,ezState,isBlock)
	{
		var tempImage = new Image();
		if (isBlock == 1)
			tempImage.src = smf_scripturl + (smf_scripturl.indexOf("?") == -1 ? "?" : "&") + "action=ezportal;sa=blockstate;blockid=" + ezBlock + ";state=" + ezState + ";sesc=" + "ec2667271b5fea8cb9490b737860d26f" +  ";" + (new Date().getTime());
		else
			tempImage.src = smf_scripturl + (smf_scripturl.indexOf("?") == -1 ? "?" : "&") + "action=ezportal;sa=columnstate;columnid=" + ezBlock + ";state=" + ezState + ";sesc=" + "ec2667271b5fea8cb9490b737860d26f" +  ";" + (new Date().getTime());

	}
	// ]]></script>
        <!-- App Indexing for Google Search -->
        <link href="http://texasmountaineers.org/forum/android-app://com.quoord.tapatalkpro.activity/tapatalk/texasmountaineers.org/forum/?location=index&amp;channel=google-indexing" rel="alternate" />
        <link href="http://texasmountaineers.org/forum/ios-app://307880732/tapatalk/texasmountaineers.org/forum/?location=index&amp;channel=google-indexing" rel="alternate" />
        
        <meta property="al:android:package" content="com.quoord.tapatalkpro.activity" />
        <meta property="al:android:url" content="tapatalk://texasmountaineers.org/forum/?location=index&amp;channel=facebook-indexing" />
        <meta property="al:android:app_name" content="Tapatalk" />
        <meta property="al:ios:url" content="tapatalk://texasmountaineers.org/forum/?location=index&amp;channel=facebook-indexing" />
        <meta property="al:ios:app_store_id" content="307880732" />
        <meta property="al:ios:app_name" content="Tapatalk" />
        
        <!-- twitter app card start-->
        <!-- https://dev.twitter.com/docs/cards/types/app-card -->
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:site" content="@tapatalk" />
        <meta name="twitter:title" content="Login" />
        <meta name="twitter:description" content="Login" />
        
        <meta name="twitter:app:id:iphone" content="307880732" />
        <meta name="twitter:app:url:iphone" content="tapatalk://texasmountaineers.org/forum/?location=index&amp;channel=twitter-indexing" />
        <meta name="twitter:app:id:ipad" content="307880732" />
        <meta name="twitter:app:url:ipad" content="tapatalk://texasmountaineers.org/forum/?location=index&amp;channel=twitter-indexing" />
        <meta name="twitter:app:id:googleplay" content="com.quoord.tapatalkpro.activity" />
        <meta name="twitter:app:url:googleplay" content="tapatalk://texasmountaineers.org/forum/?location=index&amp;channel=twitter-indexing" />
        <!-- twitter app card -->
        
</head>
<body>
<nav class="navbar navbar-default navbar-static-top" role="navigation">
	<div class="container">
		<div class="row">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand visible-xs" href="http://texasmountaineers.org/forum/index.php">TM Forum</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
		
				<li id="button_home" class="active ">
					<a href="http://texasmountaineers.org">
						Home
						
					</a>
				</li>
		
				<li id="button_help" class="">
					<a href="http://texasmountaineers.org/forum/help/">
						Help
						
					</a>
				</li>
		
				<li id="button_search" class="">
					<a href="http://texasmountaineers.org/forum/search/">
						Search
						
					</a>
				</li>
		
				<li id="button_gallery" class="">
					<a href="http://texasmountaineers.org/forum/gallery/">
						Gallery
						
					</a>
				</li>
		
				<li id="button_login" class="">
					<a href="http://texasmountaineers.org/forum/login/">
						Login
						
					</a>
				</li>
		
				<li id="button_register" class="">
					<a href="http://texasmountaineers.org/forum/register/">
						Register
						
					</a>
				</li>
				</ul>
			</div>
		</div>
	</div>
</nav>
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<a href="http://texasmountaineers.org/forum/index.php"><img src="http://texasmountaineers.org/forum/Themes/Reseller/images/txmountaineers_logosmall_150x150.png" alt="TM Forum" /></a>
			</div>
			<div class="col-md-3">
				<button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">Login</button>
				<button type="button" class="btn btn-primary" onclick="location.href='http://texasmountaineers.org/forum/index.php?action=register'">Register</button>
				<form id="guest_form" action="http://texasmountaineers.org/forum/login2/" method="post" accept-charset="ISO-8859-1"  onsubmit="hashLoginPassword(this, 'ec2667271b5fea8cb9490b737860d26f');">
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-sm">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
									<h4 class="modal-title" id="myModalLabel">Login</h4>
								</div>
								<div class="modal-body">
										<div class="form-group">
											<input type="text" name="user" class="form-control" placeholder="User" />
										</div>
										<div class="form-group">
											<input type="password" name="passwrd" class="form-control" placeholder="Password" />
										</div>
										<div class="checkbox">
											<label>
												<input name="cookielength" type="checkbox" value="-1" /> Remember me
											</label>
										</div>
								</div>
								<div class="modal-footer">
									<button type="submit" class="btn btn-success">Login</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</header>
	<div class="navigate_section">
		<div class="container">
			<div class="row">
				<ol class="breadcrumb">
					<li>
						<a href="http://texasmountaineers.org/forum/index.php"><span>TM Forum</span></a>
					</li>
					<li class="active">
						<a href="http://texasmountaineers.org/forum/forum/"><span>Forum</span></a>
					</li>
				</ol>
			</div>
		</div>
	</div>
<div class="container">
	<div class="row">
		<div id="main_content_section">
	<script type="text/javascript" src="http://texasmountaineers.org/forum/Themes/default/scripts/sha1.js"></script>
	<form action="http://texasmountaineers.org/forum/login2/" method="post" accept-charset="ISO-8859-1" name="frmLogin" id="frmLogin" onsubmit="hashLoginPassword(this, 'ec2667271b5fea8cb9490b737860d26f');">
		<div class="tborder login">
			<div class="cat_bar">
				<h3 class="catbg">Warning!</h3>
			</div>
			<p class="information centertext">
				Only paid TM members are allowed to access forum.<br />
				Please see our <a href=/membership/>membership page</a> before  <a href="http://texasmountaineers.org/forum/register/">registering an account</a> with the TM Forum.
			</p>
			<div class="cat_bar">
				<h3 class="catbg">
					<img src="http://texasmountaineers.org/forum/Themes/Reseller/images/icons/login_sm.gif" alt="" class="icon" /> Login
				</h3>
			</div>
			<span class="upperframe"><span></span></span>
			<div class="roundframe">
				<dl>
					<dt>Username:</dt>
					<dd><input type="text" name="user" size="20" class="input_text" /></dd>
					<dt>Password:</dt>
					<dd><input type="password" name="passwrd" size="20" class="input_password" /></dd>
					<dt>Minutes to stay logged in:</dt>
					<dd><input type="text" name="cookielength" size="4" maxlength="4" value="43800" class="input_text" /></dd>
					<dt>Always stay logged in:</dt>
					<dd><input type="checkbox" name="cookieneverexp" class="input_check" onclick="this.form.cookielength.disabled = this.checked;" /></dd>
				</dl>
				<p class="centertext"><input type="submit" value="Login" class="button_submit" /></p>
				<p class="centertext smalltext"><a href="http://texasmountaineers.org/forum/reminder/">Forgot your password?</a></p>
			</div>
			<span class="lowerframe"><span></span></span>
			<input type="hidden" name="hash_passwrd" value="" />
		</div>
	</form>
		<script type="text/javascript"><!-- // --><![CDATA[
			document.forms.frmLogin.user.focus();
		// ]]></script></td><!-- end center -->
		</tr>
		</table><div align="center"><span class="smalltext">Powered by <a href="http://www.ezportal.com" target="blank">EzPortal</a></span></div>
		</div>
	</div>
</div>
		<footer>
			<div class="container">
				<div class="row">
					<div class="social_icons col-lg-12">
							<a href="https://www.facebook.com/TXMountaineers/"><img src="http://texasmountaineers.org/forum/Themes/Reseller/images/social_icons/facebook.png" alt="Facebook" /></a>
					</div> 
					<div class="col-lg-12">
						
			<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;"><a href="http://texasmountaineers.org/forum/credits/" title="Simple Machines Forum" target="_blank" class="new_win">SMF 2.0.11</a> |
 <a href="http://www.simplemachines.org/about/smf/license.php" title="License" target="_blank" class="new_win">SMF &copy; 2015</a>, <a href="http://www.simplemachines.org" title="Simple Machines" target="_blank" class="new_win">Simple Machines</a>
			</span>
					</div>
					<div class="col-lg-12">
						TM Forum &copy;
 					</div>
				</div>
			</div>
		</footer>
</body></html>